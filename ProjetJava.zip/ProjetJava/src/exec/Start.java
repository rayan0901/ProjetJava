package exec;

public class Start {
    /**
     * Point d'entrée : permet d'exécuter le projet
     */
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.execution();
    }
}
