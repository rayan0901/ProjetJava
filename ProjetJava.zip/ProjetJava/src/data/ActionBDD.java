package data;

public interface ActionBDD {
}
