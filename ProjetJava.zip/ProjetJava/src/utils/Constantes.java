package utils;
// permet d'init la BDD
// toutes les strings cstes
/*
ajouter les URL
user
mdp
requêtes
 */
public class Constantes {
}
